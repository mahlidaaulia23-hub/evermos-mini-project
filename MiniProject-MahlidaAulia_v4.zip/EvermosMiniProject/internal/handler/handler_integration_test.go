
package main

import (
    "testing"
    "net/http/httptest"
    "net/http"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
    "github.com/gofiber/fiber/v2"
)

func TestRegisterEndpoint(t *testing.T) {
    db, _ := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
    db.AutoMigrate(&User{}, &Toko{})
    h := NewHandler(db)
    app := fiber.New()
    RegisterRoutesWithHandler(app, db, h)
    req := httptest.NewRequest(http.MethodPost, "/api/register", nil)
    // we need body, but minimal smoke test: expect 400 because missing body
    resp, _ := app.Test(req)
    if resp.StatusCode != 400 {
        t.Fatalf("expected 400 for missing body, got %d", resp.StatusCode)
    }
}
