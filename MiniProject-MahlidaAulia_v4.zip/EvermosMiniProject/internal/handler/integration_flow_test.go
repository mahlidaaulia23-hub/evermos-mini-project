
package main

import (
    "testing"
    "net/http"
    "net/http/httptest"
    "strings"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
    "github.com/gofiber/fiber/v2"
)

func setupTestApp(t *testing.T) *fiber.App {
    db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
    if err != nil { t.Fatal(err) }
    db.AutoMigrate(&User{}, &Toko{}, &Alamat{}, &Kategori{}, &Produk{}, &Transaksi{}, &TransaksiDetail{}, &LogProduk{})
    h := NewHandler(db)
    app := fiber.New()
    RegisterRoutesWithHandler(app, db, h)
    return app
}

func TestRegisterLoginFlow(t *testing.T) {
    app := setupTestApp(t)

    // Register
    req := httptest.NewRequest(http.MethodPost, "/api/register",
        strings.NewReader(`{"name":"Test","email":"t@test.com","phone":"081","password":"pass"}`))
    req.Header.Set("Content-Type","application/json")
    resp, _ := app.Test(req)
    if resp.StatusCode != 201 {
        t.Fatalf("expected 201 got %d", resp.StatusCode)
    }

    // Login
    req2 := httptest.NewRequest(http.MethodPost, "/api/login",
        strings.NewReader(`{"email_or_phone":"t@test.com","password":"pass"}`))
    req2.Header.Set("Content-Type","application/json")
    resp2, _ := app.Test(req2)
    if resp2.StatusCode != 200 {
        t.Fatalf("expected 200 login got %d", resp2.StatusCode)
    }
}
