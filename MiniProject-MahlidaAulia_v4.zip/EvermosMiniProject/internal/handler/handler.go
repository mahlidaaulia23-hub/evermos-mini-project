
package main

import (
    "fmt"
    "strconv"
    "time"

    "github.com/gofiber/fiber/v2"
    "github.com/golang-jwt/jwt/v4"
    "gorm.io/gorm"
)

type Handler struct {
    DB      *gorm.DB
    Usecase *UserUsecase
}

type RegisterDTO struct {
    Name     string `json:"name"`
    Email    string `json:"email"`
    Phone    string `json:"phone"`
    Password string `json:"password"`
}

type LoginDTO struct {
    EmailOrPhone string `json:"email_or_phone"`
    Password     string `json:"password"`
}

func (h *Handler) Register(c *fiber.Ctx) error {
    var dto RegisterDTO
    if err := c.BodyParser(&dto); err != nil {
        return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error":"invalid body"})
    }
    user, err := h.Usecase.Register(dto.Name, dto.Email, dto.Phone, dto.Password)
    if err != nil {
        return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error": err.Error()})
    }
    return c.Status(201).JSON(fiber.Map{"message":"registered","user_id":user.ID})
}

func (h *Handler) Login(c *fiber.Ctx) error {
    var dto LoginDTO
    if err := c.BodyParser(&dto); err != nil {
        return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"error":"invalid body"})
    }
    user, err := h.Usecase.Login(dto.EmailOrPhone, dto.Password)
    if err != nil {
        return c.Status(401).JSON(fiber.Map{"error": err.Error()})
    }
    token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
        "user_id": user.ID,
        "is_admin": user.IsAdmin,
        "exp": time.Now().Add(time.Hour*72).Unix(),
    })
    s, _ := token.SignedString([]byte(GetEnv("JWT_SECRET","secret")))
    return c.JSON(fiber.Map{"token": s})
}

// Wrapper to attach usecase to handler on startup
func NewHandler(db *gorm.DB) *Handler {
    repo := &Repo{DB: db}
    uc := &UserUsecase{Repo: repo}
    return &Handler{DB: db, Usecase: uc}
}
