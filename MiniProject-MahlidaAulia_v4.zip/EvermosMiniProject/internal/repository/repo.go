
package main

import "gorm.io/gorm"

type Repo struct {
    DB *gorm.DB
}

func (r *Repo) CreateUser(u *User) error {
    return r.DB.Create(u).Error
}

func (r *Repo) FindByEmailOrPhone(email, phone string) *User {
    var user User
    if err := r.DB.Where("email = ? OR phone = ?", email, phone).First(&user).Error; err != nil {
        return nil
    }
    return &user
}

func (r *Repo) CreateToko(t *Toko) error {
    return r.DB.Create(t).Error
}
