
package main

import "time"

type User struct {
    ID        uint   `gorm:"primaryKey"`
    Name      string
    Email     string `gorm:"uniqueIndex"`
    Phone     string `gorm:"uniqueIndex"`
    Password  string
    IsAdmin   bool
    Toko      Toko
    CreatedAt time.Time
    UpdatedAt time.Time
}

type Toko struct {
    ID      uint   `gorm:"primaryKey"`
    UserID  uint   `gorm:"index"`
    Name    string
    Address string
}

type Alamat struct {
    ID        uint   `gorm:"primaryKey"`
    UserID    uint   `gorm:"index"`
    Label     string
    Province  string
    City      string
    Address   string
    CreatedAt time.Time
}

type Kategori struct {
    ID   uint   `gorm:"primaryKey"`
    Name string `gorm:"uniqueIndex"`
}

type Produk struct {
    ID          uint    `gorm:"primaryKey"`
    TokoID      uint    `gorm:"index"`
    KategoriID  uint
    Name        string
    Price       float64
    Stock       int
    ImageURL    string
    CreatedAt   time.Time
}

type Transaksi struct {
    ID        uint   `gorm:"primaryKey"`
    UserID    uint   `gorm:"index"`
    Total     float64
    Status    string
    CreatedAt time.Time
    Details   []TransaksiDetail
}

type TransaksiDetail struct {
    ID          uint `gorm:"primaryKey"`
    TransaksiID uint `gorm:"index"`
    ProdukID    uint
    Qty         int
    Price       float64
}

type LogProduk struct {
    ID         uint `gorm:"primaryKey"`
    TransaksiID uint
    ProdukData string `gorm:"type:text"` // JSON snapshot
    CreatedAt  time.Time
}
