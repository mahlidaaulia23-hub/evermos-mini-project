
package main

import (
    "github.com/gofiber/fiber/v2"
    "github.com/golang-jwt/jwt/v4"
    "gorm.io/gorm"
)

func (h *Handler) JWTProtected(c *fiber.Ctx) error {
    auth := c.Get("Authorization")
    if auth == "" { return c.Status(401).JSON(fiber.Map{"error":"missing token"}) }
    tokenStr := auth
    token, err := jwt.Parse(tokenStr, func(t *jwt.Token) (interface{}, error) {
        return []byte(GetEnv("JWT_SECRET", "secret")), nil
    })
    if err != nil || !token.Valid { return c.Status(401).JSON(fiber.Map{"error":"invalid token"}) }
    claims := token.Claims.(jwt.MapClaims)
    uid := uint(claims["user_id"].(float64))
    // fetch user
    var user User
    h.DB.First(&user, uid)
    c.Locals("user", &user)
    return c.Next()
}

func (h *Handler) AdminOnly(c *fiber.Ctx) error {
    user := c.Locals("user").(*User)
    if user == nil || !user.IsAdmin {
        return c.Status(403).JSON(fiber.Map{"error":"admin only"})
    }
    return c.Next()
}
