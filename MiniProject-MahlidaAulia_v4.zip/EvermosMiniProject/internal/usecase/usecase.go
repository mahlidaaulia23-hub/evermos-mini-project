
package main

import (
    "errors"
    "golang.org/x/crypto/bcrypt"
)

type UserUsecase struct {
    Repo *Repo
}

func (u *UserUsecase) Register(name, email, phone, password string) (*User, error) {
    // basic validation
    if name == "" || email == "" || phone == "" || password == "" {
        return nil, errors.New("missing required fields")
    }
    if exists := u.Repo.FindByEmailOrPhone(email, phone); exists != nil {
        return nil, errors.New("email or phone already used")
    }
    pw, _ := bcrypt.GenerateFromPassword([]byte(password), 12)
    user := &User{Name: name, Email: email, Phone: phone, Password: string(pw)}
    if err := u.Repo.CreateUser(user); err != nil {
        return nil, err
    }
    // create toko
    toko := &Toko{UserID: user.ID, Name: user.Name + " Toko"}
    u.Repo.CreateToko(toko)
    return user, nil
}

func (u *UserUsecase) Login(emailOrPhone, password string) (*User, error) {
    if emailOrPhone == "" || password == "" {
        return nil, errors.New("missing credentials")
    }
    user := u.Repo.FindByEmailOrPhone(emailOrPhone, emailOrPhone)
    if user == nil {
        return nil, errors.New("invalid credentials")
    }
    if bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)) != nil {
        return nil, errors.New("invalid credentials")
    }
    return user, nil
}
