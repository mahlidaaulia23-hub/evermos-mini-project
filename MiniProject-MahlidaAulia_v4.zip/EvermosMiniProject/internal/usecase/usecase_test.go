
package main

import (
    "testing"
    "gorm.io/driver/sqlite"
    "gorm.io/gorm"
)

func setupTestDB(t *testing.T) *Repo {
    db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
    if err != nil {
        t.Fatal(err)
    }
    // migrate
    db.AutoMigrate(&User{}, &Toko{})
    return &Repo{DB: db}
}

func TestRegisterAndLogin(t *testing.T) {
    repo := setupTestDB(t)
    uc := &UserUsecase{Repo: repo}
    user, err := uc.Register("Test", "a@test.com", "081234", "pass")
    if err != nil {
        t.Fatalf("register failed: %v", err)
    }
    if user.Email != "a@test.com" {
        t.Fatalf("unexpected email")
    }
    // login success
    u2, err := uc.Login("a@test.com", "pass")
    if err != nil {
        t.Fatalf("login failed: %v", err)
    }
    if u2.ID != user.ID {
        t.Fatalf("login returned wrong user")
    }
    // login fail
    if _, err := uc.Login("a@test.com", "wrong"); err == nil {
        t.Fatalf("expected login fail for wrong password")
    }
}
