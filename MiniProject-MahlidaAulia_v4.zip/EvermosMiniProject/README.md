
# MiniProject - Evermos (Mahlida Aulia) - Enhanced

This repository is a minimal, production-oriented backend for the Rakamin Evermos mini-project.

## What changed
- Added service/usecase layer
- Added repository abstraction
- Improved validation and error handling
- Postman collection includes all endpoints
- README includes step-by-step Git instructions

## Setup

1. Copy `.env.example` to `.env` and fill database credentials.
2. Ensure MySQL is running and create a database (e.g. `evermos_db`).
3. Run:
   ```
   go mod tidy
   go run main.go
   ```
4. Use Postman collection `postman/evermos_postman_collection.json`.

## Make a local git repo and push to GitHub

Replace `<your-repo-url>` with your repository HTTPS URL.

```
git init
git add .
git commit -m "Initial Evermos mini project - Mahlida Aulia"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

If you want me to generate a ready-to-run `.git` bundle or provide commands tailored for your environment, tell me the GitHub repo URL and I will prepare a sequence of commands.



## Advanced features added
- Viper-based config loader (config/config.go)
- SQL migration files in /migrations
- Unit & integration tests (go test) using sqlite in-memory
- Rate limiting middleware
- Structured logging with zap
- GitHub Actions CI workflow (.github/workflows/ci.yml)
- push_to_github.sh prefilled with your repo URL
