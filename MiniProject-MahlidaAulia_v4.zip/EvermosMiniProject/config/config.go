
package main

import (
    "log"
    "time"

    "github.com/spf13/viper"
)

type Config struct {
    DBHost string
    DBPort int
    DBUser string
    DBPass string
    DBName string
    JWTSecret string
    ServerPort int
    RateLimitPerMinute int
}

func LoadConfig() *Config {
    viper.SetConfigFile(".env")
    viper.AutomaticEnv()
    if err := viper.ReadInConfig(); err != nil {
        // it's OK if .env not present; env vars still work
    }
    c := &Config{
        DBHost: viper.GetString("DB_HOST"),
        DBPort: viper.GetInt("DB_PORT"),
        DBUser: viper.GetString("DB_USER"),
        DBPass: viper.GetString("DB_PASS"),
        DBName: viper.GetString("DB_NAME"),
        JWTSecret: viper.GetString("JWT_SECRET"),
        ServerPort: viper.GetInt("SERVER_PORT"),
        RateLimitPerMinute: viper.GetInt("RATE_LIMIT_PER_MINUTE"),
    }
    if c.ServerPort == 0 { c.ServerPort = 8080 }
    if c.RateLimitPerMinute == 0 { c.RateLimitPerMinute = 60 }
    log.Printf("Config loaded: server port %d, rate %d/min", c.ServerPort, c.RateLimitPerMinute)
    // small delay to ensure logs flush in some environments
    time.Sleep(10 * time.Millisecond)
    return c
}
