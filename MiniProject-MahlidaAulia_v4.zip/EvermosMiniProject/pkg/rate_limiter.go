
package main

import (
    "time"

    "github.com/gofiber/fiber/v2/middleware/limiter"
    "github.com/gofiber/fiber/v2"
)

func RateLimiterConfig(rpm int) fiber.Handler {
    // limit by IP
    return limiter.New(limiter.Config{
        Max:        rpm,
        Expiration: 1 * time.Minute,
        LimitReached: func(c *fiber.Ctx) error {
            return c.Status(429).JSON(fiber.Map{"error":"rate limit exceeded"})
        },
    })
}
