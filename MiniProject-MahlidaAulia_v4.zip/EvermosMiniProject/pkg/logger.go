
package main

import (
    "go.uber.org/zap"
)

func InitLogger() (*zap.Logger, error) {
    cfg := zap.NewProductionConfig()
    cfg.DisableCaller = true
    cfg.DisableStacktrace = true
    return cfg.Build()
}
