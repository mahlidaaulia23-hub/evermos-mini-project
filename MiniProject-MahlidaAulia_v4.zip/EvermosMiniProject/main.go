
package main

import (
    "log"
    "os"

    "github.com/gofiber/fiber/v2"
    "github.com/gofiber/fiber/v2/middleware/logger"
    "github.com/joho/godotenv"
    "gorm.io/driver/mysql"
    "gorm.io/gorm"
)

func main() {
    if err := godotenv.Load(); err != nil {
        log.Println("No .env file loaded")
    }
    dsn := os.Getenv("DB_USER") + ":" + os.Getenv("DB_PASS") + "@tcp(" + os.Getenv("DB_HOST") + ":" + os.Getenv("DB_PORT") + ")/" + os.Getenv("DB_NAME") + "?charset=utf8mb4&parseTime=True&loc=Local"
    db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
    if err != nil {
        log.Fatal(err)
    }

    // Auto migrate minimal models
    db.AutoMigrate(&User{}, &Toko{}, &Alamat{}, &Kategori{}, &Produk{}, &Transaksi{}, &TransaksiDetail{}, &LogProduk{})

	cfg := LoadConfig()
	logger, _ := InitLogger()
	defer logger.Sync()


    app := fiber.New()
    app.Use(logger.New())
    // rate limiter middleware
    app.Use(RateLimiterConfig(60))


    h := NewHandler(db)
    RegisterRoutesWithHandler(app, db, h)

    log.Fatal(app.Listen(":8080"))
}
