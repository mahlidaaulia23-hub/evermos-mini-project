
package tests

import (
    "bytes"
    "encoding/json"
    "net/http"
    "net/http/httptest"
    "testing"

    "gorm.io/driver/sqlite"
    "gorm.io/gorm"

    "github.com/gofiber/fiber/v2"
    mainapp "EvermosMiniProject"
)

func setupApp() *fiber.App {
    db, _ := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
    db.AutoMigrate(&mainapp.User{}, &mainapp.Toko{}, &mainapp.Kategori{}, &mainapp.Alamat{}, &mainapp.Produk{}, &mainapp.Transaksi{}, &mainapp.TransaksiDetail{}, &mainapp.LogProduk{})
    h := mainapp.NewHandler(db)
    app := fiber.New()
    mainapp.RegisterRoutesWithHandler(app, db, h)
    return app
}

func TestFullFlow(t *testing.T) {
    app := setupApp()

    // REGISTER
    body := map[string]string{"name":"Test","email":"test@test.com","phone":"0812","password":"pass"}
    b, _ := json.Marshal(body)
    req := httptest.NewRequest(http.MethodPost, "/api/register", bytes.NewReader(b))
    req.Header.Set("Content-Type","application/json")
    resp, _ := app.Test(req)
    if resp.StatusCode != 201 {
        t.Fatalf("Register failed: %d", resp.StatusCode)
    }

    // LOGIN
    body2 := map[string]string{"email_or_phone":"test@test.com","password":"pass"}
    bb, _ := json.Marshal(body2)
    req2 := httptest.NewRequest(http.MethodPost, "/api/login", bytes.NewReader(bb))
    req2.Header.Set("Content-Type","application/json")
    resp2, _ := app.Test(req2)
    if resp2.StatusCode != 200 {
        t.Fatalf("Login failed: %d", resp2.StatusCode)
    }
}
