
package main

import (
    "github.com/gofiber/fiber/v2"
    "gorm.io/gorm"
)

func RegisterRoutesWithHandler(app *fiber.App, db *gorm.DB, h *Handler) {
    api := app.Group("/api")

    api.Post("/register", h.Register)
    api.Post("/login", h.Login)

    user := api.Group("/user", h.JWTProtected)
    user.Get("/me", h.GetMe)
    user.Put("/me", h.UpdateMe)

    toko := api.Group("/toko", h.JWTProtected)
    toko.Get("/", h.ListToko)
    toko.Post("/", h.CreateToko)

    kategori := api.Group("/kategori", h.JWTProtected, h.AdminOnly)
    kategori.Get("/", h.ListKategori)
    kategori.Post("/", h.CreateKategori)

    produk := api.Group("/produk", h.JWTProtected)
    produk.Get("/", h.ListProduk)
    produk.Post("/", h.CreateProduk)
    produk.Post("/upload", h.UploadFile)

    alamat := api.Group("/alamat", h.JWTProtected)
    alamat.Get("/", h.ListAlamat)
    alamat.Post("/", h.CreateAlamat)

    transaksi := api.Group("/transaksi", h.JWTProtected)
    transaksi.Post("/", h.CreateTransaksi)
    transaksi.Get("/", h.ListTransaksi)
}
