
-- +migrate Down
DROP TABLE IF EXISTS log_produk;
DROP TABLE IF EXISTS transaksi_detail;
DROP TABLE IF EXISTS transaksi;
DROP TABLE IF EXISTS produk;
