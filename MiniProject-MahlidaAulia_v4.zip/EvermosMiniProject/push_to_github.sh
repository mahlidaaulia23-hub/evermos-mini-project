
#!/bin/bash
set -e
REPO_URL="https://github.com/mahlida/evermos-mini-project"
git init
git add .
git commit -m "Initial Evermos mini project - Mahlida Aulia (with tests, config, migrations)"
git branch -M main
git remote add origin $REPO_URL
git push -u origin main
echo "Pushed to $REPO_URL"
